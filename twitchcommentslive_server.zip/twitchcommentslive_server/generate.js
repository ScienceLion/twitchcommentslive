const fs = require("fs");
const sharp = require("sharp");
const SOURCE = "C:\\Program Files (x86)\\Steam\\steamapps\\common\\Noita\\mods\\twitchcommentslive\\files\\entities\\fonts\\gfx\\"
const MOD_IMG_FILE_PATH = "C:\\Program Files (x86)\\Steam\\steamapps\\common\\Noita\\mods\\twitchcommentslive\\files\\entities\\"

async function makeCharXML(filename) {
	let offsetX = 0;
	let offsetY = 0;
	let pngPath = SOURCE + filename + ".png"
	try {
		// 1. Check if the PNG file exists
		if (!fs.existsSync(pngPath)) {
			 console.error(`Error: PNG file not found at ${pngPath}. Cannot generate metadata.`);
		} else {
			// 2. Use sharp to get metadata (asynchronous operation)
			const metadata = await sharp(pngPath).metadata();
			
			// 3. Extract width and height
			let width = metadata.width || 0;
			let height = metadata.height || 0;
			offsetX = Math.floor(width / 2);
			offsetY = Math.floor(height / 2);
		}
	} catch (error) {
		console.error(`Error processing image metadata for ${pngFilename}:`, error);
	}
	
    if (!fs.existsSync(MOD_IMG_FILE_PATH + "fonts\\char\\char_" + filename + ".xml")) {
		fs.writeFileSync(MOD_IMG_FILE_PATH + "fonts\\char\\char_" + filename + ".xml",
            `<Entity tags="prop"><VelocityComponent/><SpriteComponent z_index="1" image_file="mods/twitchcommentslive/files/entities/fonts/gfx/char_gfx_${filename}.xml" offset_x="${offsetX}" offset_y="${offsetY}"></SpriteComponent></Entity>`, "utf8")
	}
	if (!fs.existsSync(MOD_IMG_FILE_PATH + "fonts\\char\\pchar_" + filename + ".xml")) {
        fs.writeFileSync(MOD_IMG_FILE_PATH + "fonts\\char\\pchar_" + filename + ".xml",
            `<Entity tags="mortal"><Base file="mods/twitchcommentslive/files/entities/pbase.xml"><PhysicsImageShapeComponent image_file="mods/twitchcommentslive/files/entities/fonts/gfx/${filename}.png"/><SpriteComponent z_index="1" image_file="mods/twitchcommentslive/files/entities/fonts/gfx/char_gfx_${filename}.xml" offset_x="${offsetX}" offset_y="${offsetY}"/></Base></Entity>`, "utf8")
    }
	if (!fs.existsSync(MOD_IMG_FILE_PATH + "fonts\\gfx\\char_gfx_" + filename + ".xml")) {
        fs.writeFileSync(MOD_IMG_FILE_PATH + "fonts\\gfx\\char_gfx_" + filename + ".xml",
            `<Sprite filename="mods/twitchcommentslive/files/entities/fonts/gfx/${filename}.png"></Sprite>`, "utf8")
    }
}

const prefix = 'char_';         // The predetermined prefix to remove

// --- Function to Process Files ---
function getFileNumbers(dirPath, prefix) {
    let fileNumbers = [];

    try {
        // 1. Gather all file names in the directory
        const fileNames = fs.readdirSync(dirPath);

        // Process each file name
        for (const fileName of fileNames) {
            // Check if the file name starts with the prefix
            if (!fileName.startsWith(prefix)) {
                // Determine the part of the name after the prefix
                let numberPart = fileName;//.substring(prefix.length);

                // Remove the file extension (e.g., .txt, .jpg)
                const extension = ".png";
                numberPart = numberPart.replace(extension, '');
                
				
                // 2. Convert the resulting string to an integer
                const number = parseInt(numberPart, 10);

                // 3. Put the integer into an array, checking if conversion was successful
                if (!isNaN(number)) {
                    fileNumbers.push(number);
                }
            }
        }
    } catch (err) {
        console.error(`Error reading directory or processing files: ${err.message}`);
        return []; // Return an empty array on error
    }

    return fileNumbers;
}

// --- Execution ---
const finalNumbers = getFileNumbers(SOURCE, prefix);

for (let i in finalNumbers) {
	makeCharXML(finalNumbers[i])
}